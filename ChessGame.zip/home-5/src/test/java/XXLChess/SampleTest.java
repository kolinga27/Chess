package XXLChess;


import processing.core.PApplet;
import processing.core.PImage;
import processing.event.MouseEvent;

import org.junit.jupiter.api.Test;

import jogamp.opengl.glu.mipmap.Image;

import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;

import org.junit.jupiter.api.Assertions;

public class SampleTest {

    PImage sprite;
    
    @Test

    public void setup() {
        App app = new App();

        PApplet.runSketch(new String[]{"XXLChess.App"}, app);

        app.delay(500);
        MouseEvent mouseEvent = new MouseEvent(app, 0, 0, 0, 6*48, 7*48, 0, 0);
        app.mouseClicked(mouseEvent);

        app.chessboard();

    }

    @Test

    public void PlayingGameState() {
        App app = new App();
        PApplet.runSketch(new String[]{"XXLChess.App"}, app);
        app.delay(500);
        MouseEvent mouseEvent = new MouseEvent(app, 0, 0, 0, 6*48, 7*48, 0, 0);
        app.mouseClicked(mouseEvent);
        Assertions.assertEquals(2, app.gameState);

    }

    @Test

    public void AIGameState() {
        App app = new App();
        PApplet.runSketch(new String[]{"XXLChess.App"}, app);
        app.delay(500);
        MouseEvent mouseEvent = new MouseEvent(app, 0, 0, 0, 9*48, 7*48, 0, 0);
        app.mouseClicked(mouseEvent);
        Assertions.assertEquals(3, app.gameState);

    }




    @Test
    public void testMenuScreen() {
        App app = new App();
        app.settings();
        app.menu();
        PApplet.runSketch(new String[]{"XXLChess.App"}, app);
        PImage expectedImage = app.loadImage("/Users/vikram/Desktop/Game/src/main/resources/XXLChess/menu.png");
        PImage actualImage = app.loadImage("/Users/vikram/Desktop/Game/src/main/resources/XXLChess/menu.png");
        assertEquals(expectedImage.width, actualImage.width);
        assertEquals(expectedImage.height, actualImage.height);
    }

}
