package XXLChess;

import processing.core.PImage;
import java.util.ArrayList;

 /**
     * Chancellor Piece moves like a Knight and Rook
     */
public class Chancellor extends Pieces {


    /**
     * Constructs a new Chancellor object with the specified x & y coordinate, sprite, and color.
     *
     * @param x       x-coordinate of the piece position.
     * @param y       y-coordinate of the piece position.
     * @param sprite  image sprite representing the Rook.
     * @param isWhite whether the piece is white or black.
     */


    public Chancellor(int x, int y, PImage sprite, boolean iswhite) {

        super (x,y,sprite,iswhite);
        this.value = 8.5;
    }

    /**
     * possible movements of the Chancellor on the chessboard.
     *
     * @param board the chessboard Containing all the pecies.
     * @return the possible movements of the Chancellor in Array int[].
     */


    @Override

    public ArrayList<int[]> PossibleMovements(Pieces[][] board) {
        ArrayList<int[]> possiblemoves = new ArrayList<>();
    
        int[][] moves = {
            {-2, -1}, {-2, 1}, {2, -1}, {2, 1},
            {-1, -2}, {-1, 2}, {1, -2}, {1, 2}
        };
    
        for (int[] move : moves) {
            int newX = this.x / 48 + move[0];
            int newY = this.y / 48 + move[1];
    
            if (newX >= 0 && newX < 14 && newY >= 0 && newY < 14) {
                Pieces target = board[newX][newY];
                if (target == null || target.iswhite != this.iswhite) {
                    possiblemoves.add(new int[] {newX, newY});
                    if (target != null && target.iswhite != this.iswhite) {
                        this.capturable.add(new int[] {newX, newY});
                    }
                }
            }
        }

        // ------- Right Movements -------
        for (int x = this.x/48 + 1; x < 14; x++) {
            if (board[x][this.y/48] == null){
                possiblemoves.add(new int[] {x, this.y/48});
            }else{
                if(board[x][this.y/48].iswhite != this.iswhite){
                    this.capturable.add(new int[] {x, this.y/48});
                }
                break;
            }
            
        }

        // -------- Vertical Movements ------
        for (int y = this.y/48 + 1; y < 14; y++) {
            if (board[this.x/48][y] == null){
                possiblemoves.add(new int[] {this.x/48, y});
            }else{
                if(board[this.x/48][y].iswhite != this.iswhite){
                    this.capturable.add(new int[] {this.x/48, y});
                }
                break;
            }
            
        }

        // -------- Left Movements ---------

        for (int x = this.x/48 - 1; x >= 0; x--) {
            if (board[x][this.y/48] == null){
                possiblemoves.add(new int[] {x, this.y/48});
            }else {
                if(board[x][this.y/48].iswhite != this.iswhite){
                    this.capturable.add(new int[] {x, this.y/48});
                }
                break;
            }
            
        }

        // --------- Down Movements ----------
        for (int y = this.y/48 - 1; y >= 0; y--) {
            if (board[this.x/48][y] == null){
                possiblemoves.add(new int[] {this.x/48, y});
            }else{
                if(board[this.x/48][y].iswhite != this.iswhite){
                    this.capturable.add(new int[] {this.x/48, y});
                }
                break;
            }
            
        }
    
        return possiblemoves;
    }

    
}
