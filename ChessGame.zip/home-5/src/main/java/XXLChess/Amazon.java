package XXLChess;

import java.util.ArrayList;
import processing.core.PImage;


  /**
     * Amazon piece combines the movements of a Bishop, Knight, and Rook.
     */

public class Amazon extends Pieces {
   
 

     /**
     * Constructs a new Amazon chess piece.
     *
     * @param x      The X-coordinate of the piece on the chessboard.
     * @param y      The Y-coordinate of the piece on the chessboard.
     * @param sprite The image representing the Amazon.
     * @param iswhite whether the Amazon is white (true) or black (false).
     */
    public Amazon   (int x, int y, PImage sprite, boolean iswhite) {
        super (x,y,sprite,iswhite);
        this.value = 12;
    }

     /**
     * possible movements of the Amazon on the chessboard.
     *
     * @param board the chessboard Containing all the pecies.
     * @return the possible movements of the Amazon in Array int[].
     */


    @Override
    public ArrayList<int[]> PossibleMovements(Pieces[][] board) {
        ArrayList<int[]> possiblemoves = new ArrayList<>();
        

    // ----- BISHOP MOVEMENT ---------
        int[][] directions = {
            {-1, -1}, {-1, 1}, {1, -1}, {1, 1}
        };
    
        for (int[] direction : directions) {
            int newX = this.x / 48 + direction[0];
            int newY = this.y / 48 + direction[1];
    
            while (newX >= 0 && newX < 14 && newY >= 0 && newY < 14) {
                Pieces target = board[newX][newY];
                if (target == null) {
                    possiblemoves.add(new int[] {newX, newY});
                } else {
                    if (target.iswhite != this.iswhite) {
                        possiblemoves.add(new int[] {newX, newY});
                        this.capturable.add(new int[] {newX, newY});
                    }
                    break;
                }
                newX += direction[0];
                newY += direction[1];
            }
        }
        
        // --------- KNIGHT MOVEMENT --------------
        int[][] moves = {
            {-2, -1}, {-2, 1}, {2, -1}, {2, 1},
            {-1, -2}, {-1, 2}, {1, -2}, {1, 2}
        };
    
        for (int[] move : moves) {
            int newX = this.x / 48 + move[0];
            int newY = this.y / 48 + move[1];
    
            if (newX >= 0 && newX < 14 && newY >= 0 && newY < 14) {
                Pieces target = board[newX][newY];
                if (target == null || target.iswhite != this.iswhite) {
                    possiblemoves.add(new int[] {newX, newY});
                    if (target != null && target.iswhite != this.iswhite) {
                        this.capturable.add(new int[] {newX, newY});
                    }
                }
            }
        }

        // -------------- ROOK MOVEMENT --------------------

        // -------------  RIGHT MOVEMENT -------------------
        for (int x = this.x/48 + 1; x < 14; x++) {
            if (board[x][this.y/48] == null){
                possiblemoves.add(new int[] {x, this.y/48});
            }else{
                if(board[x][this.y/48].iswhite != this.iswhite){
                    this.capturable.add(new int[] {x, this.y/48});
                }
                break;
            }
            
        }

        // -------- VERTICAL MOVEMENT -----------------
        for (int y = this.y/48 + 1; y < 14; y++) {
            if (board[this.x/48][y] == null){
                possiblemoves.add(new int[] {this.x/48, y});
            }else{
                if(board[this.x/48][y].iswhite != this.iswhite){
                    this.capturable.add(new int[] {this.x/48, y});
                }
                break;
            }
            
        }

        // -------- LEFT MOVEMENT -----------------
        for (int x = this.x/48 - 1; x >= 0; x--) {
            if (board[x][this.y/48] == null){
                possiblemoves.add(new int[] {x, this.y/48});
            }else {
                if(board[x][this.y/48].iswhite != this.iswhite){
                    this.capturable.add(new int[] {x, this.y/48});
                }
                break;
            }
            
        }

        // --------- DOWN MOVEMENTS -----------------
        for (int y = this.y/48 - 1; y >= 0; y--) {
            if (board[this.x/48][y] == null){
                possiblemoves.add(new int[] {this.x/48, y});
            }else{
                if(board[this.x/48][y].iswhite != this.iswhite){
                    this.capturable.add(new int[] {this.x/48, y});
                }
                break;
            }
            
        }

        return possiblemoves;
    }
    
    
    

}
