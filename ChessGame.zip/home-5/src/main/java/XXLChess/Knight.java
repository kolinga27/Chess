package XXLChess;


import processing.core.PImage;
import java.util.ArrayList;

/**
     * Knight Piece moves in L shape
     */


public class Knight extends Pieces {

       /**
     * Constructs a new Knight object with the specified x & y coordinate, sprite, and color.
     *
     * @param x       x-coordinate of the piece position.
     * @param y       y-coordinate of the piece position.
     * @param sprite  image sprite representing the Rook.
     * @param isWhite whether the piece is white or black.
     */


    public Knight  (int x, int y, PImage sprite, boolean iswhite) {

        super (x,y,sprite,iswhite );
        this.value = 2;
    }
  

    /**
     * possible movements of the Knight on the chessboard.
     *
     * @param board the chessboard Containing all the pecies.
     * @return the possible movements of the Knight in Array int[].
     */


    @Override
    public ArrayList<int[]> PossibleMovements(Pieces[][] board) {
        ArrayList<int[]> possiblemoves = new ArrayList<>();
    
        int[][] moves = {
            {-2, -1}, {-2, 1}, {2, -1}, {2, 1},
            {-1, -2}, {-1, 2}, {1, -2}, {1, 2}
        };
    
        for (int[] move : moves) {
            int newX = this.x / 48 + move[0];
            int newY = this.y / 48 + move[1];
    
            if (newX >= 0 && newX < 14 && newY >= 0 && newY < 14) {
                Pieces target = board[newX][newY];
                if (target == null || target.iswhite != this.iswhite) {
                    possiblemoves.add(new int[] {newX, newY});
                    if (target != null && target.iswhite != this.iswhite) {
                        this.capturable.add(new int[] {newX, newY});
                    }
                }
            }
        }
    
        return possiblemoves;
    }
    

}


