package XXLChess;

import processing.core.PImage;
import java.util.ArrayList;

  /**
     * Bishop piece and has the movement of a Bishop.
     */

public class Bishop extends Pieces {

    /**
     * Constructs a new Bishop chess piece.
     *
     * @param x      The X-coordinate of the piece on the chessboard.
     * @param y      The Y-coordinate of the piece on the chessboard.
     * @param sprite The image representing the Amazon.
     * @param iswhite whether the Bishop is white (true) or black (false).
     
     */
    public Bishop (int x, int y, PImage sprite, boolean iswhite) {

        super (x,y,sprite,iswhite );
        this.value = 3.625;
    }

    /**
     * possible movements of the Bishop on the chessboard.
     *
     * @param board the chessboard Containing all the pecies.
     * @return the possible movements of the Bishop in Array int[].
     */


    @Override
    public ArrayList<int[]> PossibleMovements(Pieces[][] board) {
        ArrayList<int[]> possiblemoves = new ArrayList<>();
    
        int[][] directions = {
            {-1, -1}, {-1, 1}, {1, -1}, {1, 1}
        };
    
        for (int[] direction : directions) {
            int newX = this.x / 48 + direction[0];
            int newY = this.y / 48 + direction[1];
    
            while (newX >= 0 && newX < 14 && newY >= 0 && newY < 14) {
                Pieces target = board[newX][newY];
                if (target == null) {
                    possiblemoves.add(new int[] {newX, newY});
                } else {
                    if (target.iswhite != this.iswhite) {
                        possiblemoves.add(new int[] {newX, newY});
                        this.capturable.add(new int[] {newX, newY});
                    }
                    break;
                }
                newX += direction[0];
                newY += direction[1];
            }
        }
    
        return possiblemoves;
    }
    
}
