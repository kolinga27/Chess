package XXLChess;
import java.util.ArrayList;
import processing.core.PImage;


/**
* Archabishop combines the movements of a Bishop and Knight.
*/

public class Archbishop extends Pieces {


     /**
     * Constructs a new Archibishop piece.
     *
     * @param x       X-coordinate of the piece on the chessboard.
     * @param y       Y-coordinate of the piece on the chessboard.
     * @param sprite The image representing the Amazon.
     * @param iswhite whether the Archibishop is white (true) or black (false).
     */

    public Archbishop(int x, int y, PImage sprite, boolean iswhite) {

        super (x,y,sprite,iswhite);
        this.value = 7.5;
    }

    /**
     * possible movements of the Amazon on the chessboard.
     *
     * @param board the chessboard Containing all the pecies.
     * @return the possible movements of the Amazon in Array int[].
     */


    @Override
    public ArrayList<int[]> PossibleMovements(Pieces[][] board) {
        ArrayList<int[]> possiblemoves = new ArrayList<>();

        // Bishop movements
        int[][] bishopDirections = {
            {-1, -1}, {-1, 1}, {1, -1}, {1, 1}
        };

        for (int[] direction : bishopDirections) {
            int newX = this.x / 48 + direction[0];
            int newY = this.y / 48 + direction[1];

            while (newX >= 0 && newX < 14 && newY >= 0 && newY < 14) {
                Pieces target = board[newX][newY];
                if (target == null) {
                    possiblemoves.add(new int[] {newX, newY});
                } else {
                    if (target.iswhite != this.iswhite) {
                        possiblemoves.add(new int[] {newX, newY});
                        this.capturable.add(new int[] {newX, newY});
                    }
                    break;
                }
                newX += direction[0];
                newY += direction[1];
            }
        }

        // Knight movements
        int[][] knightMoves = {
            {-2, -1}, {-2, 1}, {-1, -2}, {-1, 2},
            {1, -2}, {1, 2}, {2, -1}, {2, 1}
        };

        for (int[] move : knightMoves) {
            int newX = this.x / 48 + move[0];
            int newY = this.y / 48 + move[1];

            if (newX >= 0 && newX < 14 && newY >= 0 && newY < 14) {
                Pieces target = board[newX][newY];
                if (target == null || target.iswhite != this.iswhite) {
                    possiblemoves.add(new int[] {newX, newY});
                    if (target != null) {
                        this.capturable.add(new int[] {newX, newY});
                    }
                }
            }
        }

        return possiblemoves;
    }
    
    

    
}
