package XXLChess;

import java.util.ArrayList;
import processing.core.PApplet;
import processing.core.PImage;

/**
 * A super clsss that gets inherited by all the other subclasses such as ROOK, QUEEN, KING
 */
public abstract class Pieces {
    
    protected int x;
    protected int y;
    
    protected int prevX;
    protected int prevY;


    public static final int CELLSIZE = 48;
    public static final int BOARD_WIDTH = 14;

    protected boolean iswhite;
    String Name; 
    protected boolean hasMoved;
    protected PApplet app;

    public PImage sprite; 
    protected ArrayList<int[]> possibleMovements;
    protected ArrayList<int[]> capturable;

    protected double value;
    public static int whiteScore = 0;
    public static int blackScore = 0;

    protected float moveX;
    protected float moveY;
   
    /**
     * Constructs a new Pieces object. 
     *
     * @param x         the x-coordinate of the piece
     * @param y         the y-coordinate of the piece
     * @param sprite    the image representing the piece
     * @param iswhite   whether the piece is white or not
     */

    public Pieces (int x, int y, PImage sprite, boolean iswhite) {
        this.x = x;
        this.y = y;
        this.sprite = sprite;
        this.sprite.resize(48,48);
        this.iswhite = iswhite;
        this.possibleMovements = new ArrayList<>();
        this.capturable = new ArrayList<>();
        this.hasMoved = false;
        this.prevX = prevX;
        this.prevY = prevY;
        this.value = value;
    }


    /**
     * Sets the position of the piece.
     *
     * @param x  the new x-coordinate
     * @param y  the new y-coordinate
     */

    public void setPosition(int x, int y) {
        this.x = x;
        this.y = y;
        this.hasMoved = true;
    }

    /**
     * Sets the new x-coordinate of the piece.
     *
     * @param x  Sets the new x-coordinate
     * @param prevX  stores the previous x-coordinate
     */

    public void setX(int x) {
        this.prevX = this.x;
        this.x = x;
    }

    /**
     * Sets the new y-coordinate of the piece.
     *
     * @param y  Sets the new y-coordinate
     * @param prevY  stores the previous y-coordinate
     */

    public void setY(int y) {
        this.prevY = this.y;
        this.y = y;
    }

    public int getX() {
        return this.x;
    }

    public int getY() {
        return this.y;
    }

    public void capture() {
        if (this.iswhite) {
            blackScore += this.value;
        } else {
            whiteScore += this.value;
        }
    }

    public void slowMovement(float lerp) {
        // Calculate the target position in pixels
        float targetX = x * CELLSIZE;
        float targetY = y * CELLSIZE;
        int oldX = getX()/48;
        int oldY = getY()/48;
        // Use lerp to calculate the new position
        moveX = PApplet.lerp(oldX, targetX, lerp);
        moveY = PApplet.lerp(oldY, targetY, lerp);
    }
    
  




    public void draw(PApplet app) {
        // Handles the graphics
        app.image(this.sprite, this.x, this.y);
    }   

    /**
     * Initializes a new chess piece based on a character and image path.
     *
     * @param pieceChar   the character representing the type of the piece
     * @param imagePath   the path of the image representing the piece
     * @param app         the PApplet on which to draw the piece
     * @return            the new piece
     */

    public static Pieces intializePeice(char pieceChar, String imagePath,PApplet app) {
        Pieces piece = null;
        PImage sprite = null;


        switch (pieceChar) {
            case 'r':
                sprite = app.loadImage(imagePath+"/w-rook.png");
                piece = new Rook(0,0,sprite,true);
                break;
            case 'n':
                sprite = app.loadImage(imagePath+"/w-knight.png");
                piece = new Knight(0,0,sprite,true);
                break;

            case 'b':
                sprite = app.loadImage(imagePath+"/w-bishop.png");
                piece = new Bishop(0,0,sprite,true);
                break;

            case 'h':
                sprite = app.loadImage(imagePath+"/w-archbishop.png");
                piece = new Archbishop(0,0,sprite,true);
                break;

            case 'c':
                sprite = app.loadImage(imagePath+"/w-camel.png");
                piece = new Camel(0,0,sprite,true);
                break;

            case 'g':
                sprite = app.loadImage(imagePath+"/w-knight-king.png");
                piece = new General(0,0,sprite,true);
                break;

            case 'a':
                sprite = app.loadImage(imagePath+"/w-amazon.png");
                piece = new Amazon(0,0,sprite,true);
                break;

            case 'k':
                sprite = app.loadImage(imagePath+"/w-king.png");
                piece = new King(0,0,sprite,true);
                break;

            case 'e':
                sprite = app.loadImage(imagePath+"/w-chancellor.png");
                piece = new Chancellor(0,0,sprite,true);
                break;

            case 'q':
                sprite = app.loadImage(imagePath+"/w-queen.png");
                piece = new Queen(0,0,sprite,true);
                break;

            case 'p':
                sprite = app.loadImage(imagePath+"/w-pawn.png");
                piece = new Commoner(0,0,sprite,true);
                break;
            
            // black peices 
                
            case 'R':
                sprite = app.loadImage(imagePath+"/b-rook.png");
                piece = new Rook(0,0,sprite,false);
                break;
            case 'N':
                sprite = app.loadImage(imagePath+"/b-knight.png");
                piece = new Knight(0,0,sprite,false);
                break;

            case 'B':
                sprite = app.loadImage(imagePath+"/b-bishop.png");
                piece = new Bishop(0,0,sprite,false);
                break;

            case 'H':
                sprite = app.loadImage(imagePath+"/b-archbishop.png");
                piece = new Archbishop(0,0,sprite,false);
                break;

            case 'C':
                sprite = app.loadImage(imagePath+"/b-camel.png");
                piece = new Camel(0,0,sprite,false);
                break;

            case 'G':
                sprite = app.loadImage(imagePath+"/b-knight-king.png");
                piece = new General(0,0,sprite,false);
                break;

            case 'A':
                sprite = app.loadImage(imagePath+"/b-amazon.png");
                piece = new Amazon(0,0,sprite,false);
                break;

            case 'K':
                sprite = app.loadImage(imagePath+"/b-king.png");
                piece = new King(0,0,sprite,false);
                break;

            case 'E':
                sprite = app.loadImage(imagePath+"/b-chancellor.png");
                piece = new Chancellor(0,0,sprite,false);
                break;

            case 'Q':
                sprite = app.loadImage(imagePath+"/b-queen.png");
                piece = new Queen(0,0,sprite,false);
                break;

            case 'P':
                sprite = app.loadImage(imagePath+"/b-pawn.png");
                piece = new Commoner(0,0,sprite,false);
                break;
            


        }
        return piece;
        

        
    }


    
    /**
     * Computes all possible movements for the piece on the given board.
     *
     * @param board  the 2D array representing the chess board
     * @return       a list of int arrays, each containing the x and y coordinates of a possible move
     */

    public ArrayList<int[]> PossibleMovements(Pieces[][] board) {
        ArrayList<int[]> possiblemoves = new ArrayList<>();
        
        // ------- Right Movements -------
        for (int x = this.x/48 + 1; x < 14; x++) {
            if (board[x][this.y/48] == null){
                possiblemoves.add(new int[] {x, this.y/48});
            }else{
                if(board[x][this.y/48].iswhite != this.iswhite){
                    this.capturable.add(new int[] {x, this.y/48});
                }
                break;
            }
            
        }

        // -------- Vertical Movements ------
        for (int y = this.y/48 + 1; y < 14; y++) {
            if (board[this.x/48][y] == null){
                possiblemoves.add(new int[] {this.x/48, y});
            }else{
                if(board[this.x/48][y].iswhite != this.iswhite){
                    this.capturable.add(new int[] {this.x/48, y});
                }
                break;
            }
            
        }

        // -------- Left Movements ---------

        for (int x = this.x/48 - 1; x >= 0; x--) {
            if (board[x][this.y/48] == null){
                possiblemoves.add(new int[] {x, this.y/48});
            }else {
                if(board[x][this.y/48].iswhite != this.iswhite){
                    this.capturable.add(new int[] {x, this.y/48});
                }
                break;
            }
            
        }

        // --------- Down Movements ----------
        for (int y = this.y/48 - 1; y >= 0; y--) {
            if (board[this.x/48][y] == null){
                possiblemoves.add(new int[] {this.x/48, y});
            }else{
                if(board[this.x/48][y].iswhite != this.iswhite){
                    this.capturable.add(new int[] {this.x/48, y});
                }
                break;
            }
            
        }
       
        return possiblemoves;
    }
    
     
    public ArrayList<int[]> Capturable(Pieces[][] board) {
        return this.capturable;
    }

    /**
     * Checks if a given position is within the chess board.
     *
     * @param x  the x-coordinate to check
     * @param y  the y-coordinate to check
     * @return   true if the position is within the bounds, false otherwise
     */
    
     protected boolean isInBounds(int x, int y) {
        return x >= 0 && x < BOARD_WIDTH && y >= 0 && y < BOARD_WIDTH;
    }
    

    


    
}