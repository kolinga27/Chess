package XXLChess;

//PFont calibri;

//import org.reflections.Reflections;
//import org.reflections.scanners.Scanners;
import processing.core.PApplet;
import processing.core.PImage;
import processing.data.JSONObject;
import processing.data.JSONArray;
import processing.core.PFont;
import processing.event.MouseEvent;
import java.io.BufferedReader;
import java.awt.Color;


import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

import com.jogamp.nativewindow.util.Point;
import java.io.*;
import java.util.*;
import java.io.BufferedReader;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
     * App class is an extention of the PApplet
     */
public class App extends PApplet {

    public static final int SPRITESIZE = 480;
    public static final int CELLSIZE = 48;
    public static final int SIDEBAR = 120;
    public static final int BOARD_WIDTH = 14;
    public static final int rows = 14;
    public static final int cols = 14;

    public static int WIDTH = CELLSIZE*BOARD_WIDTH+SIDEBAR;
    public static int HEIGHT = BOARD_WIDTH*CELLSIZE;

    public static final int FPS = 60;
	
    public String configPath;

    public ArrayList<Pieces> pieces = null;
    public ArrayList<int[]> possiblemoves; 
    public ArrayList<int[]> capturable;

    public Pieces[][] board = new Pieces[14][14];

    public GameState gameState;


    PImage menuScreen;

    private boolean isWhiteTurn = true; // Assume white goes first
    private boolean isBoardReversed = false; 

    public int playerTime = 180;
    public int cpuTime = 180;

    private int playerTimeIncrement;
    private int cpuTimeIncrement;
    public int lastTimeUpdated = 0;


    /**
     * Controls the state of the game state 
     */


    public enum GameState {
          /**
             * The game is in the menu state.
             */
        MENU,

        /**
         * The game is in the 2 player state.
         */

        PLAYING,

        /**
         * The game is in the AI state versuing the human Player.
         */
        AI,

        /**
         * The game Over is state is when the game is over.
         */
        GAME_OVER,
    } 

    public App() {
        this.configPath = "config.json";
        
    }

    /**
     * Initialise the setting of the window size.
    */
    public void settings() {
        size(WIDTH, HEIGHT);
        gameState = GameState.MENU;
        menuScreen = loadImage("/Users/vikram/Desktop/Game/src/main/resources/XXLChess/menu.png");

    }


    /**
     * Creates a chessboard by drawing it in the screen
     */

    public void chessboard() {
        background(180,180,180);//grey background
        noStroke();
        for (int i = 0; i < BOARD_WIDTH; i++) {
            for (int j = 0; j < BOARD_WIDTH; j++) { // iterate each tile into 14x14 grid
                if ((i + j) % 2 == 0) { //checks current tile is cream or brown
                    fill(242,217,187); // cream
                } else {
                     fill(191,138,107); // brown
                }

               rect(i * CELLSIZE, j * CELLSIZE, CELLSIZE, CELLSIZE); // draws rectangle at specific position on the grid
            }
        }
    }


    /**
     * Creates a menu page by drawing it in the screen
     */
    public void menu() {
        menuScreen.resize(792, 672);
        image(menuScreen, 0, 0);

    }


    public void updates() {
        for (Pieces piece : pieces) {
            piece.draw(this);

        }

    
    }
    public void setup() {
        frameRate(FPS);

        JSONObject conf = loadJSONObject(new File(this.configPath));
        

        // Retrieve values from the JSONObject
        String layout = conf.getString("layout");

        // Retrieve nested objects
        JSONObject time_controls = conf.getJSONObject("time_controls");
        JSONObject player_time = time_controls.getJSONObject("player");
        int player_seconds = player_time.getInt("seconds");
        int player_increment = player_time.getInt("increment");

        JSONObject cpu_time = time_controls.getJSONObject("cpu");
        int cpu_seconds = cpu_time.getInt("seconds");
        int cpu_increment = cpu_time.getInt("increment");
        String player_colour = conf.getString("player_colour");
        float piece_movement_speed = conf.getFloat("piece_movement_speed");
        int max_movement_time = conf.getInt("max_movement_time");


        playerTime = player_seconds;
        cpuTime = cpu_seconds;

        
        playerTimeIncrement = player_increment;
        cpuTimeIncrement = cpu_increment;
    
        
        pieces = new ArrayList<>();
    
        
        // Reads the charcters from the level1.txt file and intialises the pecies in the right place accroding to the given coordinates. 

        String imagePath = "src/main/resources/XXLChess";

        try {
            BufferedReader reader = new BufferedReader(new FileReader(layout));
            String line;
            int y = 0;

            while ((line = reader.readLine()) != null) {
                for (int x = 0; x < line.length(); x++) {
                    char pieceChar = line.charAt(x);
                    Pieces piece = Pieces.intializePeice(pieceChar, imagePath, this);
                    if (piece != null) {
                        piece.setX(x * CELLSIZE);
                        piece.setY(y * CELLSIZE);
                        pieces.add(piece);
                        this.board[x][y] = piece;
                    }
                }
                y++;
            }
            reader.close();


        } catch (IOException e) {
            e.printStackTrace();
        }

        if (pieces.get(0).iswhite) {
            isBoardReversed = true;
        } else {
            isBoardReversed = false;
        }
        
        
      
        switch (gameState) {
            case MENU:
                menu();
                break;
            case PLAYING:
                break;
            case GAME_OVER:
                break;
        }


    }

    

    /**
     * Receive key pressed signal from the keyboard.
    */
    public void keyPressed(){
        if (key == 'e') { 
         gameState = GameState.GAME_OVER;
         exit();
      }

    }
    
    /**
     * Receive key released signal from the keyboard.
    */
    public void keyReleased(){
        
    }




    Pieces selectedPiece = null;

    /**
     * Receives a mocuse event from the click handler and runs the logic mostly depending on the state of the the enum and the player moves 
    */ 


    @Override
    public void mouseClicked(MouseEvent e) {
        int clickX = floor(e.getX() / CELLSIZE);
        int clickY = floor(e.getY() / CELLSIZE);
    
        if (clickX >= 5 && clickX <= 7 && clickY >= 8 && clickY <= 10) {
        
            gameState = GameState.PLAYING;
            background(128); 
            chessboard();
            updates();
        }

        if (gameState.equals(GameState.PLAYING)) {

        
            if (selectedPiece != null) {
                // Move the selected piece to the clicked cell
                int newX = clickX * CELLSIZE;
                int newY = clickY * CELLSIZE;
                
                this.possiblemoves = selectedPiece.PossibleMovements(this.board);
                this.capturable =  selectedPiece.capturable;
                ArrayList<int[]> capturableMoves = selectedPiece.capturable;
                boolean isValidMove = false;
                int oldX = selectedPiece.getX()/48;
                int oldY = selectedPiece.getY()/48;
                
                for (int[] move : possiblemoves) {
                    if (move[0] == clickX && move[1] == clickY) {
                        isValidMove = true;
                        break;
                    }
                }
    
                for (int[] move : capturableMoves) {
                    if (move[0] == clickX && move[1] == clickY) {
                        isValidMove = true;
                        break;
                    }
                }
    
                if (isValidMove) {
    
    
                    Pieces capturedPiece = board[clickX][clickY];
                    if (capturedPiece != null) {
                        // Remove the captured piece from the board and pieces list
                        pieces.remove(capturedPiece);
                    }
    
                    
                    // Set the selected PEICE NEW position AND UPDATES IT IN THE ALL PEICES 
                    selectedPiece.setPosition(newX, newY);
                    board[clickX][clickY] = selectedPiece;
                    selectedPiece.capturable.clear();
                    board[oldX][oldY] = null;
                    
                   

                    tryPawnPromotion(clickX, clickY);
                    
                    chessboard();
                
                    fill(255, 255, 0);
                    rect(oldX *48, oldY *48, CELLSIZE, CELLSIZE);
                    rect(newX, newY, CELLSIZE, CELLSIZE);
        
                
                    updates();
               
                    
                }

               
                isWhiteTurn = !isWhiteTurn;
                selectedPiece = null;
    
    
    
            } else {
                // Check if a piece is clicked
                for (Pieces piece : pieces) {
                    if (piece != null && piece.getX() <= e.getX() && e.getX() <= piece.getX() + CELLSIZE
                        && piece.getY() <= e.getY() && e.getY() <= piece.getY() + CELLSIZE && piece.iswhite == isWhiteTurn) {
                        
                       
                        // Finds the piece that is clicked in the board and updates the selected piece as the peice in the board
                        selectedPiece = piece;
                        
                        chessboard();
    
                        this.possiblemoves = selectedPiece.PossibleMovements(this.board); // Stores the possible moves of the selected piece from the board in the psiible moves
                        this.capturable =   selectedPiece.capturable; // sTores the capturable move of the selected piece
                        ArrayList<int[]> capturableMoves = selectedPiece.capturable; // Create a new capturableMoves ArrayList here
                        fill(0, 255, 0);
                        rect(selectedPiece.getX(), selectedPiece.getY(), CELLSIZE, CELLSIZE);

                        
                        updates();
                        
                        // --------- DISPLAYS THE POSSIBLE MOVES OF THE SELECTED PIECE ---------------
                        for (int[] moves : possiblemoves) {
                            int x = moves[0] * 48 ;
                            int y = moves[1] * 48 ;
                            fill(200,200,255);
                            rect(x, y, CELLSIZE, CELLSIZE);
                        }
    
    
                        selectedPiece.PossibleMovements(this.board).clear();  // Clears the possible moves array in the APP CLASS 
    
    
                         // --------- DISPLAYS THE CAPTURABLE MOVES OF THE SELECTED PIECE ---------------
    
                        for (int[] moves : capturableMoves) {
                            int x = moves[0] * 48 ;
                            int y = moves[1] * 48 ;
                            fill(255, 100, 100);
                            rect(x, y, CELLSIZE, CELLSIZE);
                        }
    
                        updates();
    
                        selectedPiece.capturable.clear(); // Clears the CAPTURABLE moves array in the APP CLASS 
    
                        break; // We want to break because we don't want to it keep displaying the the selected piece
                    }
                }
                
                
                
                
            }

        
        }
          
        if (clickX >= 8 && clickX <= 10 && clickY >= 8 && clickY <= 10 && !gameState.equals(GameState.PLAYING)) {
            gameState = GameState.AI;
            background(128); 
            chessboard();
            updates();
        }

        if (gameState.equals(GameState.AI)) {
            if (isWhiteTurn) {
                if (selectedPiece != null) {
                    makeMove(selectedPiece, clickX, clickY);
                    selectedPiece = null;
                    
                } else {
                    for (Pieces piece : pieces) {
                        if (piece != null && piece.getX() <= e.getX() && e.getX() <= piece.getX() + CELLSIZE
                            && piece.getY() <= e.getY() && e.getY() <= piece.getY() + CELLSIZE && piece.iswhite == isWhiteTurn) {
                            
                           
                            // Finds the piece that is clicked in the board and updates the selected piece as the peice in the board
                            selectedPiece = piece;
                            
                            chessboard();
        
                            this.possiblemoves = selectedPiece.PossibleMovements(this.board); // Stores the possible moves of the selected piece from the board in the psiible moves
                            this.capturable =   selectedPiece.capturable; // sTores the capturable move of the selected piece
                            ArrayList<int[]> capturableMoves = selectedPiece.capturable; // Create a new capturableMoves ArrayList here
                            fill(0, 255, 0);
                            rect(selectedPiece.getX(), selectedPiece.getY(), CELLSIZE, CELLSIZE);
    
                            
                            updates();
                            
                            // --------- DISPLAYS THE POSSIBLE MOVES OF THE SELECTED PIECE ---------------
                            for (int[] moves : possiblemoves) {
                                int x = moves[0] * 48 ;
                                int y = moves[1] * 48 ;
                                fill(200,200,255);
                                rect(x, y, CELLSIZE, CELLSIZE);
                            }
        
        
                            selectedPiece.PossibleMovements(this.board).clear();  // Clears the possible moves array in the APP CLASS 
        
        
                             // --------- DISPLAYS THE CAPTURABLE MOVES OF THE SELECTED PIECE ---------------
        
                            for (int[] moves : capturableMoves) {
                                int x = moves[0] * 48 ;
                                int y = moves[1] * 48 ;
                                fill(255, 100, 100);
                                rect(x, y, CELLSIZE, CELLSIZE);
                            }
        
                            updates();
        
                            selectedPiece.capturable.clear(); // Clears the CAPTURABLE moves array in the APP CLASS 
        
                            break; // We want to break because we don't want to it keep displaying the the selected piece
                        }
                    
                    
                    
                    
                    
                    }

                }
            } else { // AI's turn
                ArrayList<Pieces> aiPieces = new ArrayList<>();
                for (Pieces piece : pieces) {
                    if (!piece.iswhite) {
                        aiPieces.add(piece);
                    }
                }
    
                // Choose a random piece and move
                Pieces selectedPiece = PieceSelection(aiPieces);
                int[] move = MoveSelection(selectedPiece, board);
    
                if (move != null) {
                    // Implement the move
                    clickX = move[0];
                    clickY = move[1];
                    makeMove(selectedPiece, clickX, clickY);
                    selectedPiece = null;
                    
                }
            }
        }
        
    }




    
   
    
    private void tryPawnPromotion(int clickX, int clickY) {
        if (selectedPiece instanceof Commoner) {  // Pawn Promotion to Queen 
            Pieces promotedPiece = null;
            int indexInPieces = pieces.indexOf(selectedPiece);
    
            if (!isBoardReversed) {
                if (selectedPiece.iswhite && selectedPiece.getY() == floor(6* CELLSIZE)) {
                    promotedPiece = new Queen(selectedPiece.getX(), selectedPiece.getY(), loadImage("/Users/vikram/Desktop/Game/src/main/resources/XXLChess/w-queen.png"), true);
                } else if (!selectedPiece.iswhite && selectedPiece.getY() == floor(7* CELLSIZE)) {
                    promotedPiece = new Queen(selectedPiece.getX(), selectedPiece.getY(), loadImage("//Users/vikram/Desktop/Game/src/main/resources/XXLChess/b-queen.png"), false);
                }
            } else {
                if (selectedPiece.iswhite && selectedPiece.getY() == floor(7 * CELLSIZE)) {
                    promotedPiece = new Queen(selectedPiece.getX(), selectedPiece.getY(), loadImage("/Users/vikram/Desktop/Game/src/main/resources/XXLChess/w-queen.png"), true);
                } else if (!selectedPiece.iswhite && selectedPiece.getY() == floor(1 * CELLSIZE)) {
                    promotedPiece = new Queen(selectedPiece.getX(), selectedPiece.getY(), loadImage("//Users/vikram/Desktop/Game/src/main/resources/XXLChess/b-queen.png"), false);
                }
            }
    
            if (promotedPiece != null) {
                if (indexInPieces != -1) {
                    pieces.set(indexInPieces, promotedPiece);
                }
                // Update the piece in the board array
                board[clickX][clickY] = promotedPiece;
            }
        }
    }

    public Pieces PieceSelection(ArrayList<Pieces> pieces){
        Random rand = new Random();
        Pieces randomPiece = pieces.get(rand.nextInt(pieces.size()));
        return randomPiece;
    }
    
    public int[] MoveSelection(Pieces piece, Pieces[][] board){
        Random rand = new Random();
        ArrayList<int[]> possibleMoves = piece.PossibleMovements(board);
        if (!possibleMoves.isEmpty()){
            int[] randomMove = possibleMoves.get(rand.nextInt(possibleMoves.size()));
            return randomMove;
        }
        return null;
    }
    
    private void makeMove(Pieces piece, int clickX, int clickY) {
        int newX = clickX * CELLSIZE;
        int newY = clickY * CELLSIZE;
        int oldX = piece.getX()/48;
        int oldY = piece.getY()/48;
    
        ArrayList<int[]> possiblemoves = piece.PossibleMovements(this.board);
        ArrayList<int[]> capturableMoves = piece.capturable;
    
        // Check if the move is valid
        boolean isValidMove = false;
        for (int[] move : possiblemoves) {
            if (move[0] == clickX && move[1] == clickY) {
                isValidMove = true;
                break;
            }
        }
        for (int[] move : capturableMoves) {
            if (move[0] == clickX && move[1] == clickY) {
                isValidMove = true;
                break;
            }
        }
    
        if (isValidMove) {
            Pieces capturedPiece = board[clickX][clickY];
            if (capturedPiece != null) {
                pieces.remove(capturedPiece);
            }
    
            // Set the selected PIECE NEW position AND UPDATES IT IN THE ALL PIECES 
            piece.setPosition(newX, newY);
            board[clickX][clickY] = piece;
            piece.capturable.clear();
            board[oldX][oldY] = null;
    
            tryPawnPromotion(clickX, clickY);
            chessboard();
    
            fill(255, 255, 0);
            rect(oldX *48, oldY *48, CELLSIZE, CELLSIZE);
            rect(newX, newY, CELLSIZE, CELLSIZE);
    
            updates();
            isWhiteTurn = !isWhiteTurn;
        }
    
       
    }
    

    @Override
    public void mouseDragged(MouseEvent e) {
        
    }

    /**
     * Draw all elements in the game by current frame. 
    */
    public void draw() {

     
            
        
    }
	
	// Add any additional methods or attributes you want. Please put classes in different files.


    public static void main(String[] args) {
        PApplet.main("XXLChess.App");
    }

}
