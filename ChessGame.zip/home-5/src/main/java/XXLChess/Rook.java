package XXLChess;


import processing.core.PImage;
/**
 * Rook chess piece The Rook can move horizontally or vertically across the board.
 */
public class Rook extends Pieces {

    /**
     * Constructs a new Rook object with the specified coordinates, sprite, and color.
     *
     * @param x       x-coordinate of the Rook's position.
     * @param y       y-coordinate of the Rook's position.
     * @param sprite  image sprite representing the Rook.
     * @param isWhite whether the Rook is white or black.
     */

    public Rook (int x, int y, PImage sprite, boolean iswhite) {

        super (x,y,sprite,iswhite );
        this.value = 5.25;
    }

    

   

}
