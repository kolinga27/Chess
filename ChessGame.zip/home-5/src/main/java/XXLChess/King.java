package XXLChess;


import processing.core.PImage;
import java.util.ArrayList;


/**
     * King Piece moves in all directions by 1
     */

public class King extends Pieces {


       /**
     * Constructs a new King object with the specified x & y coordinate, sprite, and color.
     *
     * @param x       x-coordinate of the piece position.
     * @param y       y-coordinate of the piece position.
     * @param sprite  image sprite representing the Rook.
     * @param isWhite whether the piece is white or black.
     */

    public King  (int x, int y, PImage sprite, boolean iswhite) {

        super (x,y,sprite,iswhite);
        this.value =  Double.POSITIVE_INFINITY;
    }


    /**
     * possible movements of the King on the chessboard.
     *
     * @param board the chessboard Containing all the pecies.
     * @return the possible movements of the King in Array int[].
     */



    @Override
    public ArrayList<int[]> PossibleMovements(Pieces[][] board) {
        ArrayList<int[]> possiblemoves = new ArrayList<>();

        // King movements
        int[][] kingMoves = {
            {-1, -1}, {-1, 0}, {-1, 1}, {0, -1},
            {0, 1}, {1, -1}, {1, 0}, {1, 1}
        };

        for (int[] move : kingMoves) {
            int newX = this.x / 48 + move[0];
            int newY = this.y / 48 + move[1];

            if (newX >= 0 && newX < 14 && newY >= 0 && newY < 14) {
                Pieces target = board[newX][newY];
                if (target == null || target.iswhite != this.iswhite) {
                    possiblemoves.add(new int[] {newX, newY});
                    if (target != null) {
                        this.capturable.add(new int[] {newX, newY});
                    }
                }
            }
        }

        return possiblemoves;
    }


}

