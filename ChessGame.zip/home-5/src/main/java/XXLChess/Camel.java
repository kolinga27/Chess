package XXLChess;


import processing.core.PImage;
import java.util.ArrayList;

/**
* Camel combines the movements of a Knight but moves an increment of 1. 
*/
public class Camel extends Pieces {


      /**
     * Constructs a new Camel object with the specified x & y coordinate, sprite, and color.
     *
     * @param x       x-coordinate of the piece position.
     * @param y       y-coordinate of the piece position.
     * @param sprite  image sprite representing the Rook.
     * @param isWhite whether the piece is white or black.
     */


    public Camel  (int x, int y, PImage sprite, boolean iswhite) {
        super (x,y,sprite,iswhite);
        this.value = 2;
    }


     /**
     * possible movements of the Camel on the chessboard.
     *
     * @param board the chessboard Containing all the pecies.
     * @return the possible movements of the Camel in Array int[].
     */

    @Override

    public ArrayList<int[]> PossibleMovements(Pieces[][] board) {
        ArrayList<int[]> possiblemoves = new ArrayList<>();
    
        int[][] moves = {
            {-3, -1}, {-3, 1}, {3, -1}, {3, 1},
            {-1, -3}, {-1, 3}, {1, -3}, {1, 3}
        };
    
        for (int[] move : moves) {
            int newX = this.x / 48 + move[0];
            int newY = this.y / 48 + move[1];
    
            if (newX >= 0 && newX < 14 && newY >= 0 && newY < 14) {
                Pieces target = board[newX][newY];
                if (target == null || target.iswhite != this.iswhite) {
                    possiblemoves.add(new int[] {newX, newY});
                    if (target != null && target.iswhite != this.iswhite) {
                        this.capturable.add(new int[] {newX, newY});
                    }
                }
            }
        }
    
        return possiblemoves;
    }
    
    
}


