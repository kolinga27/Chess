package XXLChess;

import java.util.ArrayList;
import processing.core.PImage;

 /**
     * Commoner Piece moves like a Pawn
     */
public class Commoner extends Pieces {

    public static final int CELLSIZE = 48;
    public static final int BOARD_WIDTH = 14;


      /**
     * Constructs a new Commoner object with the specified x & y coordinate, sprite, and color.
     *
     * @param x       x-coordinate of the piece position.
     * @param y       y-coordinate of the piece position.
     * @param sprite  image sprite representing the Rook.
     * @param isWhite whether the piece is white or black.
     */


    public Commoner(int x, int y, PImage sprite, boolean iswhite) {
        super(x, y, sprite, iswhite);
        this.value = 1.0;
    }

    /**
     * possible movements of the Commoner = Pawn on the chessboard.
     *
     * @param board the chessboard Containing all the pecies.
     * @return the possible movements of the Pawn in Array int[].
     */


    @Override
    public ArrayList<int[]> PossibleMovements(Pieces[][] board) {
        this.possibleMovements.clear();

        int direction = iswhite ? -1 : 1;
        int nextY = (y / CELLSIZE) + direction;

        if (isInBounds(x / CELLSIZE, nextY)) {
            if (board[x / CELLSIZE][nextY] == null) {
                this.possibleMovements.add(new int[]{x / CELLSIZE, nextY});
            }
        }

        if (!super.hasMoved && board[x / CELLSIZE][nextY] == null && board[x / CELLSIZE][nextY + direction] == null) {
            this.possibleMovements.add(new int[]{x / CELLSIZE, nextY + direction});
        }

        for (int dx = -1; dx <= 1; dx += 2) {
            int nextX = (x / CELLSIZE) + dx;
            if (isInBounds(nextX, nextY)) {
                Pieces targetPiece = board[nextX][nextY];
                if (targetPiece != null && targetPiece.iswhite != this.iswhite) {
                    this.capturable.add(new int[]{nextX, nextY});
                }
            }
        }

        return this.possibleMovements;
    }

    
}
